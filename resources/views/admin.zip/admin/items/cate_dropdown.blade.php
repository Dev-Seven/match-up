<select class="form-control custom-select" name="category_id">
    <option value=""></option>
    @foreach($subcategories as $cate)
    <option value="{{$cate->id}}">{{$cate->category_name}}</option>
    @endforeach
</select>