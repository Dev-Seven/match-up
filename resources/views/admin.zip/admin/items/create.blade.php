@extends('layouts.app_admin')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Items List</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-default">
                        <div class="card-header">
                            <h3 class="card-title">Items List</h3>
                        </div>
                        <form action="{{route('admin.items.store')}}" method="post" id="items_create">
                            @csrf
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Restaurant</label>
                                            <select class="browser-default custom-select" name="restaurant_id" id="category">
                                                <option selected></option>
                                                @foreach ($restaurantNames as $item)
                                                <option value="{{ $item->id }}">{{ $item->restaurant_name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Category</label>
                                            <select class="browser-default custom-select" name="category_id" id="subcategory">
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label> Item Name</label>
                                            <input type="text" class="form-control" name="item_name" placeholder="Enter Item Name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Status</label>
                                            <select class="form-control custom-select" name="status">
                                                <option value="">Select Status</option>
                                                <option value="1">Active</option>
                                                <option value="0">InActive</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="card-footer">
                                        <a href="{{route('admin.items.index')}}" class="btn btn-danger btn_loader">Cancel</a>
                                        <button type="submit" class="btn btn-primary loader_class">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript">
   
$(document).ready(function(){
    $('#category').change(function() {
    var restaurant_id = $(this).val();
    var token = "{{csrf_token()}}";
    $.ajax({            
        url:"{{ route('admin.items.category_listing') }}",
        type:"POST",
        data: {restaurant_id: restaurant_id,_token:token},
        success:function (data) {
            $('#subcategory').html(data);
        }
    })
               
  });  
});
</script>
@endsection


