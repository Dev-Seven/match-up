@extends('layouts.app_admin')
@section('content')
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Restaurant Detail</h1>
                </div>
                <div class="col-sm-6 text-right">
                    <a href="{{route('admin.restaurant.index')}}" class="btn btn-danger btn_loader"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Restaurant Detail</h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <th>Banner Image</th>
                                        <td>
                                            @if($user->restaurant_banner_img != '' && file_exists(public_path('users/'.$user->restaurant_banner_img)))
                                            <img src="{{asset('users/'.$user->restaurant_banner_img)}}" style="height: 80px; width: 80px;" alt="Profile Picture" class="img-circle elevation-2" />
                                            @else
                                            <img src="{{asset('users/avatar.jpg')}}" alt="Profile Picture" style="height: 80px; width: auto;" class="img-circle elevation-2" />
                                            @endif
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Restaurant Name</th>
                                        <td>{{$user->restaurant_name}}</td>
                                    </tr>
                                    <tr>
                                        <th>Latitude</th>
                                        <td>{{$user->latitude}}</td>
                                    </tr>
                                    <tr>
                                        <th>Longitude</th>
                                        <td>
                                            {{$user->longitude}}
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            @if($user->status == 1)
                                            <span style="color:green;">Active</span> @else <span style="color:red;">InActive</span> @endif
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@endsection