@extends('layouts.app_admin')
@section('content')
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Categories List</h1>
                </div>
                <div class="col-sm-6 text-right">
                    <a href="{{route('admin.category.create')}}" class="btn btn-success btn_loader"><Strong><i class="fa fa-plus"></i> New</strong></a>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Categories List</h3>
                        </div>
                        <div class="card-body">
                            <table id="category_list_table" style="width: 100%;" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <!-- <th>Image</th> -->
                                        <th>Category Name</th>
                                        <th>Restaurant Name</th>
                                        <th>Item Name</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if(!empty($category_list) && count($category_list) > 0)
                                        @foreach($category_list as $key => $value)
                                        <tr>
                                            <!-- <td>
                                                @if($value->image != '' && file_exists(public_path('users/'.$value->image)))
                                                <img src="{{asset('users/'.$value->image)}}" style="height: 40px; width: 40px;" alt="Profile Picture" class="img-circle elevation-2" />
                                                @else
                                                <img src="{{asset('users/avatar.jpg')}}" alt="Profile Picture" style="height: 40px; width: auto;" class="img-circle elevation-2" />
                                                @endif
                                            </td> -->
                                            <td>{{ucfirst($value->category_name)}}</td>
                                            <td>{{ucfirst($value->restaurant_name)}}</td>
                                            <td>{{ucfirst($value->item_name)}}</td>
                                            
                                            <td>
                                                @if($value->status == 1)
                                                Active @else InActive @endif
                                            </td>
                                            <td class="text-center">
                                                <a href="{{route('admin.category.edit',$value->id)}}" class="btn icon_loader btn-sm btn-primary"><i class="fa fa-pen"></i>
                                                </a>
                                                <a href="{{route('admin.category.view',$value->id)}}" class="btn icon_loader btn-sm btn-info"><i class="fa fa-eye"></i>
                                                </a>
                                                <a href="javascript:void(0)" class="btn btn-sm btn-danger delete_button" data-id="{{$value->id}}"><i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    @else
                                    <tr>
                                        <td colspan="10">No Client Found.</td>
                                    </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Popup modal for logout start -->
<div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Are You sure?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure to Delete Client ?
            </div>
            <form method="post" action="{{route('admin.user.delete')}}">
                @csrf
                <input type="hidden" name="id" class="user_id">
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger btn_loader">Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Popup modal for logout end -->
<script type="text/javascript">
    $(document).on('click','.delete_button',function(){
        $('#deleteModel').modal('show');
        $('.user_id').val($(this).attr('data-id'));
    })
</script>
@endsection